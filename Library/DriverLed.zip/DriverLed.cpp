#include "Arduino.h"
#include "DriverLed.h"


DriverLed :: DriverLed (int LED_R, int LED_G, int LED_B) 
{
  pinMode(LED_R, OUTPUT);
  pinMode(LED_G, OUTPUT);
  pinMode(LED_B, OUTPUT);
  
_LED_R = LED_R;
_LED_G = LED_G;
_LED_B = LED_B;
}

void DriverLed:: colorselec(int color) 
{
  digitalWrite(_LED_R,color%2?HIGH:LOW);
  digitalWrite(_LED_G,(color/2)%2?HIGH:LOW);
  digitalWrite(_LED_B,(color/4)%2?HIGH:LOW);
}