#ifndef DriverLed_h
#define DriverLed_h
#include "Arduino.h" 
class DriverLed
{
 public :
 DriverLed (int LED_R, int LED_G, int LED_B) ; // constructor
 void colorselec(int color);
  private :
    int _LED_R;
    int _LED_G;
	int _LED_B;
};
#endif
